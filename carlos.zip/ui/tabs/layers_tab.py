from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QListWidget, QListWidgetItem, QTableWidget, QTableWidgetItem, QAbstractItemView
from PySide6.QtCore import Qt
from core.signals import signals
from core.models import AgentFunction

class LayersTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)

        layout.addWidget(QLabel("Existing Layers:"))
        self.layer_table = QTableWidget(0, 1)
        self.layer_table.setHorizontalHeaderLabels(["Layer Name"])
        self.layer_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.layer_table.cellClicked.connect(self.select_layer)
        layout.addWidget(self.layer_table)

        layout.addWidget(QLabel("Functions for Selected Layer:"))
        self.func_list = QListWidget()
        self.func_list.setSelectionMode(QListWidget.MultiSelection)
        layout.addWidget(self.func_list)

        layout.addWidget(QLabel("Add New Layer:"))
        self.layer_name_edit = QLineEdit()
        layout.addWidget(self.layer_name_edit)

        self.add_btn = QPushButton("Add Layer")
        self.add_btn.clicked.connect(self.add_layer)
        layout.addWidget(self.add_btn)

        self.layer_store = []  # list of dicts {name, functions}
        self.functions = []    # list of all available functions

        signals.agent_added.connect(self.receive_agent)

    def receive_agent(self, agent):
        new_func_names = [f"{agent.name}::{f.name}" for f in agent.functions]
        self.functions.extend(new_func_names)
        self.refresh_function_list([])

    def add_layer(self):
        name = self.layer_name_edit.text().strip()
        if not name:
            return

        func_names = [item.text() for item in self.func_list.selectedItems()]
        self.layer_store.append({"name": name, "functions": func_names})
        self.refresh_layer_table()
        self.layer_name_edit.clear()
        self.func_list.clearSelection()

    def refresh_layer_table(self):
        self.layer_table.setRowCount(0)
        for layer in self.layer_store:
            row = self.layer_table.rowCount()
            self.layer_table.insertRow(row)
            self.layer_table.setItem(row, 0, QTableWidgetItem(layer["name"]))

    def select_layer(self, row, col):
        if row >= len(self.layer_store):
            return
        selected_layer = self.layer_store[row]
        self.refresh_function_list(selected_layer["functions"])

    def refresh_function_list(self, selected_funcs):
        self.func_list.clear()
        for fname in self.functions:
            item = QListWidgetItem(fname)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Checked if fname in selected_funcs else Qt.Unchecked)
            self.func_list.addItem(item)

    def update_function_list(self, new_funcs):
        self.functions = new_funcs
        self.refresh_function_list([])
